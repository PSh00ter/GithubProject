let colors = ["orange", "purple", "black"];
let pumpkinX = [];
let batX = [];

function setup() {
  createCanvas(400, 400);
  print(colors.length);
  for (let i = 0; i < 7; i++) {
    pumpkinX[i] = 50 + i * 70;
  }
}

function draw() {
  background(0);
  batX[0] = mouseX;
  for (let i = 0; i < pumpkinX.length; i++) {
    fill(237, 120, 62)
    ellipse(pumpkinX[i], 300, 40, 40);
    fill(8, 112, 27)
    rect(pumpkinX[i] - 3, 270, 6, 10);
    pumpkinX[i] += 1;
    if (pumpkinX[i] > 400) {
      pumpkinX[i] = 0;
    }
  }
  for (let i = 0; i < batX.length; i++) {
    fill(237, 120, 62);
    ellipse(batX[0], 200, 12, 8);
  }
}