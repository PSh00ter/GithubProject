function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
  print(getCloudCount());
}

function draw() {
  background(200, 255, 251);
  fill(245, 255, 153);
  ellipse(300, 50, 80, 80);
  for (let i = 0; i < getCloudCount(); i++) {
    drawCloud(80 + i * 60, 100, 0.8 * i * 0.2, i * 10);
  }
  drawCloud(320, 70);
}

function drawCloud(x, y) {
  push();
  translate(x, y);
  scale(1);
  rotate(-190);
  fill(255);
  stroke(150);
  ellipse(0, 0, 80, 40);
  ellipse(30, 20, 90, 50);
  ellipse(40, 30, 80, 40);
  ellipse(100, 70, 50, 20);
  pop();
}

function getCloudCount() {
  return 8;
}