let palette;

function setup() {
  pixelDensity(1);
  createCanvas(400, 400);
  palette = createPalette();
}

function draw() {
  background(220);
  palette.add(color("magenta"));
  palette.add(color("red"));
  palette.add(color('aqua'));
  palette.draw();
  noLoop();
  palette.next();
}